def Add(x,y):
    return x+y
def Sub(x,y):
    return x-y
def Mul(x,y):
    return x*y
def Div(x,y):
    return x/y

x = int(input("x = "))
y = int(input("y = "))
print("Add = ",Add(x, y))
print("Sub = ",Sub(x, y))
print("Mul = ",Mul(x, y))
print("Div = ",Div(x, y))